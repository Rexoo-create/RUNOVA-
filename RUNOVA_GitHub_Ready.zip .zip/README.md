# RUNOVA — Flutter starter app (v2, fixed)

Running tracker with live GPS, route map, history and a sample coach.

## Build the APK with GitHub (no Flutter install needed)

1. Create a new GitHub repository and upload everything in this folder to the `main` branch
   (including the hidden `.github` folder).
2. Open the **Actions** tab, choose **Build RUNOVA APK**, and tap **Run workflow**
   (it also runs on every push to `main`).
3. When it finishes (about 5 to 10 minutes), open the run and download the **runova-apk** artifact.
4. Unzip it and install `app-release.apk` on your Android phone
   (allow "install unknown apps" when asked).

The release APK is signed with a debug key, which is fine for personal use but not for the Play Store.

## First-time setup on your own computer (alternative)

This zip contains the app code but not the generated Android/iOS project files.
Create them once with the Flutter SDK installed (Flutter 3.22+):

```bash
cd runova_flutter_starter
flutter create --org com.runova.app --project-name runova .
flutter pub get
flutter run
```

`flutter create` only adds missing files; your `lib/` code and `AndroidManifest.xml` are kept.
After it finishes, open `android/app/src/main/AndroidManifest.xml` and confirm the
`ACCESS_FINE_LOCATION`, `ACCESS_COARSE_LOCATION` and `INTERNET` permissions are still there.

For iOS, add to `ios/Runner/Info.plist` inside the main `<dict>`:

```xml
<key>NSLocationWhenInUseUsageDescription</key>
<string>RUNOVA uses your location to record your running route and distance.</string>
```

Build an APK: `flutter build apk --release`

## What was fixed in v2

- Coach plan showed a literal `\n`; now shows proper line breaks.
- Distance no longer stays near zero on phones that report GPS speed as 0.
- Elevation gain is smoothed (less GPS noise); max elevation no longer starts at 0.
- Runs under 20 m or 10 s are not saved.
- Live map now follows your position.
- Screen stays awake during a run (wakelock_plus) so tracking is not interrupted.
- Saved routes are reduced to about 150 points so history stays fast.
- Finish dialog now also shows average pace.
- Map settings moved to `lib/config.dart` (package name and tile URL).
- Removed deprecated `withOpacity`; sign-in screen now says it is a demo.

## Before publishing

1. **Sign-in is a demo.** Any valid-looking email and 6+ character password is accepted
   and nothing is verified. Replace `lib/services/auth_service.dart` with Firebase Auth or similar.
2. **Map tiles.** Set `kPackageName` in `lib/config.dart` to your real app id and switch
   `kTileUrl` to a provider that permits app use; OpenStreetMap's free server is for light use.
3. **Background tracking** is not included. Keep RUNOVA open (the screen stays awake).
4. History is stored on the device only (no cloud backup).
5. GPS distance, speed, elevation and calories are estimates; not a medical or safety device.
6. The coach shows a sample plan from local rules, not a live AI model.
7. Heart rate, voice updates and auto-pause are not included.

## Structure

```text
lib/
  main.dart
  config.dart
  screens/  auth, home, run, coach, history, profile
  services/ auth, music, run_history
```
