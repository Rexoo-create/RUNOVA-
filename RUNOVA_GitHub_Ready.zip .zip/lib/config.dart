/// Change these before publishing.
/// kPackageName must match the applicationId / bundle id you used in `flutter create --org`.
const String kPackageName = 'com.runova.app';

/// OpenStreetMap's free tile server is for light/testing use only.
/// For a public release, switch to a tile provider that allows app use (e.g. MapTiler, Stadia, Mapbox).
const String kTileUrl = 'https://tile.openstreetmap.org/{z}/{x}/{y}.png';
