import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import 'home_screen.dart';

class AuthScreen extends StatefulWidget {
  final VoidCallback onThemeToggle;
  const AuthScreen({super.key, required this.onThemeToggle});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool createAccount = false;
  bool busy = false;
  String? error;

  Future<void> submit() async {
    setState(() { busy = true; error = null; });
    try {
      if (createAccount) {
        await AuthService.signUp(email.text, password.text);
      } else {
        await AuthService.signIn(email.text, password.text);
      }
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(
        builder: (_) => HomeScreen(onThemeToggle: widget.onThemeToggle),
      ));
    } catch (e) {
      setState(() => error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() { email.dispose(); password.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final lime = const Color(0xFFB8F34A);
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Align(alignment: Alignment.topRight, child: IconButton(
                onPressed: widget.onThemeToggle, icon: const Icon(Icons.brightness_6_rounded))),
              const SizedBox(height: 24),
              Text('RUNOVA', textAlign: TextAlign.center,
                style: TextStyle(color: lime, fontSize: 34, fontWeight: FontWeight.w900, letterSpacing: 5)),
              const SizedBox(height: 8),
              Text('RUN BEYOND LIMITS', textAlign: TextAlign.center,
                style: TextStyle(color: Theme.of(context).hintColor, letterSpacing: 3, fontSize: 11)),
              const SizedBox(height: 44),
              Text(createAccount ? 'Create your account' : 'Welcome back',
                style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text(createAccount ? 'Start tracking your progress.' : 'Sign in to continue your journey.'),
              const SizedBox(height: 24),
              TextField(controller: email, keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(labelText: 'Email', prefixIcon: Icon(Icons.email_outlined), border: OutlineInputBorder())),
              const SizedBox(height: 14),
              TextField(controller: password, obscureText: true,
                decoration: const InputDecoration(labelText: 'Password', prefixIcon: Icon(Icons.lock_outline), border: OutlineInputBorder())),
              if (error != null) Padding(padding: const EdgeInsets.only(top: 12),
                child: Text(error!, style: const TextStyle(color: Colors.red))),
              const SizedBox(height: 20),
              FilledButton(
                style: FilledButton.styleFrom(backgroundColor: lime, foregroundColor: Colors.black, padding: const EdgeInsets.all(16)),
                onPressed: busy ? null : submit,
                child: Text(busy ? 'PLEASE WAIT...' : createAccount ? 'CREATE ACCOUNT' : 'SIGN IN'),
              ),
              const Padding(padding: EdgeInsets.only(top: 8), child: Text('Demo sign-in: stored on this device only, not a real account.', textAlign: TextAlign.center, style: TextStyle(fontSize: 11))),
              TextButton(onPressed: () => setState(() { createAccount = !createAccount; error = null; }),
                child: Text(createAccount ? 'Already have an account? Sign in' : 'New here? Create an account')),
            ]),
          ),
        ),
      ),
    );
  }
}
