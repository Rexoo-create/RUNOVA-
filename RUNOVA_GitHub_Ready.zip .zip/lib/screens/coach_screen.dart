import 'package:flutter/material.dart';

class CoachScreen extends StatefulWidget {
  const CoachScreen({super.key});
  @override
  State<CoachScreen> createState() => _CoachScreenState();
}

class _CoachScreenState extends State<CoachScreen> {
  String goal = 'Run 5K comfortably';
  String level = 'Beginner';
  String result = 'Choose your goal and level, then create a starter plan.';

  void generatePlan() {
    setState(() {
      result = 'Your starter plan\n\n'
        '• 3 running days per week\n'
        '• 2 easy runs at a comfortable, conversational effort\n'
        '• 1 gentle interval session with walking recoveries\n'
        '• Rest or light activity between harder sessions\n'
        '• Increase distance gradually and stop if you feel pain or unwell.\n\n'
        'Goal: $goal\nLevel: $level\n\n'
        'This is an in-app sample plan, not a live AI-generated assessment.';
    });
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    Text('AI RUNNING COACH', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900)),
    const SizedBox(height: 8),
    const Text('Set a goal to receive a training-plan preview.'),
    const SizedBox(height: 20),
    DropdownButtonFormField<String>(value: goal, decoration: const InputDecoration(labelText: 'Your goal', border: OutlineInputBorder()),
      items: const ['Run 2K comfortably', 'Run 5K comfortably', 'Improve 5K time', 'Build endurance'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
      onChanged: (v) => setState(() => goal = v!)),
    const SizedBox(height: 14),
    DropdownButtonFormField<String>(value: level, decoration: const InputDecoration(labelText: 'Experience level', border: OutlineInputBorder()),
      items: const ['Beginner', 'Intermediate', 'Experienced'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
      onChanged: (v) => setState(() => level = v!)),
    const SizedBox(height: 16),
    FilledButton.icon(onPressed: generatePlan, icon: const Icon(Icons.auto_awesome), label: const Text('CREATE TRAINING PLAN')),
    const SizedBox(height: 20),
    Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: Theme.of(context).cardColor, borderRadius: BorderRadius.circular(20)),
      child: Text(result, style: const TextStyle(height: 1.5))),
  ]);
}
