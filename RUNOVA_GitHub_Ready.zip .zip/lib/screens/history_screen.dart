import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import '../config.dart';
import '../services/run_history_service.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});
  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  List<RunRecord> runs = [];
  bool loading = true;
  String filter = 'All time';

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    final data = await RunHistoryService.getRuns();
    if (!mounted) return;
    setState(() { runs = data; loading = false; });
  }

  List<RunRecord> get visibleRuns {
    final now = DateTime.now();
    return runs.where((r) {
      if (filter == 'This week') return now.difference(r.date).inDays < 7 && !r.date.isAfter(now);
      if (filter == 'This month') return r.date.year == now.year && r.date.month == now.month;
      return true;
    }).toList();
  }

  String _duration(int seconds) {
    final h = seconds ~/ 3600, m = (seconds % 3600) ~/ 60, s = seconds % 60;
    return h > 0 ? '${h}h ${m}m' : '${m}m ${s}s';
  }
  String _date(DateTime d) => '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}  ${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

  Future<void> _delete(RunRecord run) async {
    final confirm = await showDialog<bool>(context: context, builder: (context) => AlertDialog(
      title: const Text('Delete this run?'),
      content: const Text('This activity will be removed from your history.'),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('CANCEL')),
        FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('DELETE'))],
    ));
    if (confirm == true) { await RunHistoryService.deleteRun(run.id); await _load(); }
  }

  @override
  Widget build(BuildContext context) {
    final list = visibleRuns;
    final totalKm = list.fold<double>(0, (sum, r) => sum + r.distanceMeters / 1000);
    final totalSeconds = list.fold<int>(0, (sum, r) => sum + r.movingSeconds);
    return RefreshIndicator(
      onRefresh: _load,
      child: loading
        ? const ListView(children: [SizedBox(height: 180), Center(child: CircularProgressIndicator())])
        : ListView(padding: const EdgeInsets.all(18), children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('RUNNING HISTORY', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900, letterSpacing: 1)),
            DropdownButton<String>(value: filter, items: const ['All time', 'This week', 'This month'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) => setState(() => filter = v!)),
          ]),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: _summary('TOTAL RUNS', '${list.length}')),
            const SizedBox(width: 10),
            Expanded(child: _summary('DISTANCE', '${totalKm.toStringAsFixed(1)} km')),
            const SizedBox(width: 10),
            Expanded(child: _summary('MOVING TIME', _duration(totalSeconds))),
          ]),
          const SizedBox(height: 18),
          if (list.isEmpty) Padding(padding: const EdgeInsets.only(top: 70), child: Column(children: [
            const Icon(Icons.directions_run, size: 58, color: Color(0xFF9BCB3B)),
            const SizedBox(height: 14),
            Text('No saved runs yet', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 8),
            const Text('Finish a GPS run and it will appear here.', textAlign: TextAlign.center),
          ])) else ...list.map((run) => _runCard(run)),
        ]),
    );
  }

  Widget _summary(String title, String value) => Container(
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(color: Theme.of(context).cardColor, borderRadius: BorderRadius.circular(16)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: TextStyle(fontSize: 9, color: Theme.of(context).hintColor, fontWeight: FontWeight.bold)),
      const SizedBox(height: 7), Text(value, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
    ]),
  );

  Widget _runCard(RunRecord run) => Card(
    margin: const EdgeInsets.only(bottom: 12),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
    child: InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => _RunDetailsScreen(run: run))),
      child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [const Icon(Icons.calendar_today_outlined, size: 15, color: Color(0xFF9BCB3B)), const SizedBox(width: 8), Expanded(child: Text(_date(run.date), style: TextStyle(color: Theme.of(context).hintColor, fontSize: 12))),
          IconButton(tooltip: 'Delete run', onPressed: () => _delete(run), icon: const Icon(Icons.delete_outline, color: Colors.redAccent)),
        ]),
        Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text('${(run.distanceMeters / 1000).toStringAsFixed(2)}', style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900)),
          const Padding(padding: EdgeInsets.only(bottom: 6, left: 5), child: Text('KM')),
          const Spacer(), Text('${run.pace} /km', style: const TextStyle(fontWeight: FontWeight.bold)),
        ]),
        const Divider(height: 20),
        Wrap(spacing: 18, runSpacing: 8, children: [
          _smallMetric(Icons.timer_outlined, _duration(run.movingSeconds)),
          _smallMetric(Icons.speed, '${run.averageSpeed.toStringAsFixed(1)} km/h'),
          _smallMetric(Icons.trending_up, '${run.elevationGain.toStringAsFixed(0)} m climb'),
        ]),
        const SizedBox(height: 8), Align(alignment: Alignment.centerRight, child: Text('VIEW DETAILS  →', style: TextStyle(color: Theme.of(context).colorScheme.primary, fontSize: 11, fontWeight: FontWeight.bold))),
      ])),
    ),
  );

  Widget _smallMetric(IconData icon, String value) => Row(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 15, color: const Color(0xFF9BCB3B)), const SizedBox(width: 5), Text(value, style: const TextStyle(fontSize: 12))]);
}

class _RunDetailsScreen extends StatelessWidget {
  final RunRecord run;
  const _RunDetailsScreen({required this.run});

  String _duration(int seconds) {
    final h = seconds ~/ 3600, m = (seconds % 3600) ~/ 60, s = seconds % 60;
    return h > 0 ? '${h}h ${m}m ${s}s' : '${m}m ${s}s';
  }

  @override
  Widget build(BuildContext context) {
    final route = run.route.map((p) => LatLng(p[0], p[1])).toList();
    final center = route.isNotEmpty ? route.first : const LatLng(20.5937, 78.9629);
    return Scaffold(
      appBar: AppBar(title: const Text('RUN DETAILS')),
      body: ListView(children: [
        SizedBox(height: 280, child: FlutterMap(options: MapOptions(initialCenter: center, initialZoom: route.length > 1 ? 15 : 5), children: [
          TileLayer(urlTemplate: kTileUrl, userAgentPackageName: kPackageName),
          if (route.length > 1) PolylineLayer(polylines: [Polyline(points: route, strokeWidth: 5, color: const Color(0xFF9BCB3B))]),
          if (route.isNotEmpty) MarkerLayer(markers: [Marker(point: route.first, width: 28, height: 28, child: const Icon(Icons.location_on, color: Colors.green, size: 28)), Marker(point: route.last, width: 28, height: 28, child: const Icon(Icons.flag, color: Colors.red, size: 26))]),
        ])),
        Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${run.date.day.toString().padLeft(2, '0')}/${run.date.month.toString().padLeft(2, '0')}/${run.date.year}  ${run.date.hour.toString().padLeft(2, '0')}:${run.date.minute.toString().padLeft(2, '0')}', style: TextStyle(color: Theme.of(context).hintColor)),
          const SizedBox(height: 8), Text('${(run.distanceMeters / 1000).toStringAsFixed(2)} KM', style: const TextStyle(fontSize: 42, fontWeight: FontWeight.w900)),
          const SizedBox(height: 16),
          Wrap(spacing: 10, runSpacing: 10, children: [
            _detail(context, 'Moving time', _duration(run.movingSeconds)),
            _detail(context, 'Elapsed time', _duration(run.elapsedSeconds)),
            _detail(context, 'Average pace', '${run.pace} /km'),
            _detail(context, 'Average speed', '${run.averageSpeed.toStringAsFixed(1)} km/h'),
            _detail(context, 'Max speed', '${run.maxSpeed.toStringAsFixed(1)} km/h'),
            _detail(context, 'Elevation gain', '${run.elevationGain.toStringAsFixed(0)} m'),
            _detail(context, 'Max elevation', '${run.maxElevation.toStringAsFixed(0)} m'),
            _detail(context, 'Estimated calories', '${run.calories.toStringAsFixed(0)} kcal'),
          ]),
          if (route.isEmpty) const Padding(padding: EdgeInsets.only(top: 14), child: Text('No GPS route was recorded for this activity.')),
        ])),
      ]),
    );
  }

  Widget _detail(BuildContext context, String label, String value) => Container(width: 155, padding: const EdgeInsets.all(13), decoration: BoxDecoration(color: Theme.of(context).cardColor, borderRadius: BorderRadius.circular(15)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label, style: TextStyle(fontSize: 11, color: Theme.of(context).hintColor)), const SizedBox(height: 6), Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16))]));
}
