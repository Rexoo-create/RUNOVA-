import 'package:flutter/material.dart';
import '../services/auth_service.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const CircleAvatar(radius: 42, backgroundColor: Color(0xFFB8F34A), child: Icon(Icons.person, size: 46, color: Colors.black)),
    const SizedBox(height: 14),
    const Center(child: Text('RUNOVA ATHLETE', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 2, fontSize: 18))),
    const SizedBox(height: 5),
    Center(child: Text(AuthService.email, style: TextStyle(color: Theme.of(context).hintColor))),
    const SizedBox(height: 24),
    Card(child: Column(children: const [
      ListTile(leading: Icon(Icons.shield_outlined), title: Text('Account'), subtitle: Text('Demo local sign-in is active')),
      Divider(height: 1),
      ListTile(leading: Icon(Icons.favorite_border), title: Text('Heart rate'), subtitle: Text('Not included in RUNOVA')),
      Divider(height: 1),
      ListTile(leading: Icon(Icons.cloud_outlined), title: Text('Cloud backup'), subtitle: Text('Not available in this starter version')),
    ])),
    const SizedBox(height: 16),
    Text('RUN BEYOND LIMITS', textAlign: TextAlign.center, style: TextStyle(color: Theme.of(context).hintColor, letterSpacing: 2, fontWeight: FontWeight.bold)),
  ]);
}
