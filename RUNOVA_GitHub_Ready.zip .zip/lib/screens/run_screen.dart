import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import '../config.dart';
import '../services/music_service.dart';
import '../services/run_history_service.dart';

class RunScreen extends StatefulWidget {
  const RunScreen({super.key});
  @override
  State<RunScreen> createState() => _RunScreenState();
}

class _RunScreenState extends State<RunScreen> {
  final MapController map = MapController();
  StreamSubscription<Position>? subscription;
  Timer? ticker;
  final List<LatLng> points = [];
  bool running = false, paused = false;
  DateTime? startedAt;
  int elapsedSeconds = 0, movingSeconds = 0;
  double distanceMeters = 0, elevationGain = 0, maxElevation = 0;
  double maxSpeed = 0, currentSpeed = 0;
  Position? previous;
  double? smoothAlt, refAlt;
  bool hasAltitude = false;

  String duration(int seconds) {
    final h = seconds ~/ 3600, m = (seconds % 3600) ~/ 60, s = seconds % 60;
    return h > 0 ? '${h.toString().padLeft(2,'0')}:${m.toString().padLeft(2,'0')}:${s.toString().padLeft(2,'0')}' :
      '${m.toString().padLeft(2,'0')}:${s.toString().padLeft(2,'0')}';
  }
  String pace() {
    if (distanceMeters < 10 || movingSeconds == 0) return '--:--';
    final sec = (movingSeconds / (distanceMeters / 1000)).round();
    return '${(sec ~/ 60).toString().padLeft(2,'0')}:${(sec % 60).toString().padLeft(2,'0')}';
  }

  Future<void> start() async {
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Location permission is required to track a run.')));
      return;
    }
    final enabled = await Geolocator.isLocationServiceEnabled();
    if (!enabled) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please turn on GPS/location services.')));
      return;
    }
    setState(() {
      running = true; paused = false; startedAt = DateTime.now();
      elapsedSeconds = 0; movingSeconds = 0; distanceMeters = 0;
      elevationGain = 0; maxElevation = 0; maxSpeed = 0; currentSpeed = 0;
      points.clear(); previous = null;
      smoothAlt = null; refAlt = null; hasAltitude = false;
    });
    WakelockPlus.enable(); // keep the screen awake so GPS tracking continues
    ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (running && mounted) setState(() => elapsedSeconds++);
    });
    subscription = Geolocator.getPositionStream(locationSettings: const LocationSettings(
      accuracy: LocationAccuracy.bestForNavigation, distanceFilter: 3,
    )).listen((p) {
      if (!running || paused) return;
      if (p.accuracy > 30) return;
      final current = LatLng(p.latitude, p.longitude);
      double speed = p.speed.isFinite ? math.max(0.0, p.speed).toDouble() : 0.0;
      if (previous != null) {
        final delta = Geolocator.distanceBetween(previous!.latitude, previous!.longitude, p.latitude, p.longitude);
        final dt = p.timestamp.difference(previous!.timestamp).inMilliseconds / 1000.0;
        // Some phones report speed as 0; fall back to distance / time.
        if (speed < 0.1 && dt > 0) speed = delta / dt;
        // Ignore implausible GPS jumps; the speed threshold filters stationary drift.
        if (dt > 0 && delta >= 1.5 && delta < 100 && speed >= 0.6) {
          distanceMeters += delta;
          movingSeconds += math.max(1, dt.round());
        }
      }
      // Smooth altitude, then count climbs of 2 m or more (reduces GPS noise).
      if (p.altitude.isFinite) {
        smoothAlt = smoothAlt == null ? p.altitude : smoothAlt! * 0.8 + p.altitude * 0.2;
        refAlt ??= smoothAlt;
        if (smoothAlt! - refAlt! >= 2) { elevationGain += smoothAlt! - refAlt!; refAlt = smoothAlt; }
        else if (smoothAlt! < refAlt! - 2) { refAlt = smoothAlt; }
        if (!hasAltitude || smoothAlt! > maxElevation) maxElevation = smoothAlt!;
        hasAltitude = true;
      }
      currentSpeed = speed * 3.6;
      maxSpeed = math.max(maxSpeed, currentSpeed).toDouble();
      previous = p;
      points.add(current);
      try { map.move(current, points.length == 1 ? 16 : map.camera.zoom); } catch (_) {}
      if (mounted) setState(() {});
    });
  }

  void pause() {
    setState(() { paused = true; });
    subscription?.pause();
  }
  void resume() {
    setState(() { paused = false; previous = null; });
    subscription?.resume();
  }
  List<List<double>> _routeForSave() {
    // Keep at most ~150 points so history stays fast.
    final step = math.max(1, (points.length / 150).ceil());
    final out = <List<double>>[];
    for (var i = 0; i < points.length; i += step) {
      out.add(<double>[points[i].latitude, points[i].longitude]);
    }
    if (points.isNotEmpty && (points.length - 1) % step != 0) {
      out.add(<double>[points.last.latitude, points.last.longitude]);
    }
    return out;
  }

  Future<void> finish() async {
    await subscription?.cancel();
    ticker?.cancel();
    WakelockPlus.disable();
    if (!mounted) return;
    setState(() { running = false; paused = false; });

    // Do not save empty or accidental runs.
    if (distanceMeters < 20 || elapsedSeconds < 10) {
      showDialog(context: context, builder: (_) => AlertDialog(
        title: const Text('Run too short'),
        content: const Text('This run was under 20 m or 10 seconds, so it was not saved.'),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
      ));
      return;
    }

    final record = RunRecord(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      date: startedAt ?? DateTime.now(),
      distanceMeters: distanceMeters,
      movingSeconds: movingSeconds,
      elapsedSeconds: elapsedSeconds,
      elevationGain: elevationGain,
      maxElevation: hasAltitude ? maxElevation : 0,
      maxSpeed: maxSpeed,
      calories: (distanceMeters / 1000) * 60, // rough estimate only
      route: _routeForSave(),
    );
    await RunHistoryService.saveRun(record);

    if (!mounted) return;
    showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text('Run finished & saved'),
      content: Text('Distance: ${(distanceMeters/1000).toStringAsFixed(2)} km\nMoving time: ${duration(movingSeconds)}\nElapsed time: ${duration(elapsedSeconds)}\nAvg pace: ${pace()} /km\nElevation gain: ${elevationGain.toStringAsFixed(0)} m\nMax elevation: ${hasAltitude ? maxElevation.toStringAsFixed(0) : '--'} m\n\nYour run is saved in Running History.'),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('CLOSE'))],
    ));
  }

  @override
  void dispose() { subscription?.cancel(); ticker?.cancel(); WakelockPlus.disable(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final km = distanceMeters / 1000;
    return Scaffold(
      appBar: AppBar(title: const Text('LIVE RUN')),
      body: Column(children: [
        Expanded(flex: 5, child: FlutterMap(
          mapController: map,
          options: MapOptions(initialCenter: const LatLng(20.5937, 78.9629), initialZoom: 5),
          children: [
            TileLayer(urlTemplate: kTileUrl, userAgentPackageName: kPackageName),
            if (points.isNotEmpty) PolylineLayer(polylines: [Polyline(points: points, strokeWidth: 5, color: const Color(0xFF8CC63F))]),
            if (points.isNotEmpty) MarkerLayer(markers: [Marker(point: points.last, width: 36, height: 36, child: const Icon(Icons.location_pin, color: Colors.red, size: 36))]),
          ],
        )),
        Expanded(flex: 6, child: ListView(padding: const EdgeInsets.all(18), children: [
          Center(child: Text('${km.toStringAsFixed(2)} KM', style: const TextStyle(fontSize: 46, fontWeight: FontWeight.w900))),
          const Center(child: Text('DISTANCE')),
          const SizedBox(height: 18),
          Wrap(spacing: 10, runSpacing: 10, children: [
            _value('Moving time', duration(movingSeconds)),
            _value('Elapsed time', duration(elapsedSeconds)),
            _value('Avg pace', '${pace()} /km'),
            _value('Speed', '${currentSpeed.toStringAsFixed(1)} km/h'),
            _value('Max speed', '${maxSpeed.toStringAsFixed(1)} km/h'),
            _value('Elevation gain', '${elevationGain.toStringAsFixed(0)} m'),
            _value('Max elevation', '${hasAltitude ? maxElevation.toStringAsFixed(0) : '--'} m'),
          ]),
          const SizedBox(height: 16),
          Row(children: [
            Expanded(child: OutlinedButton.icon(onPressed: () => MusicService.openMusic(context), icon: const Icon(Icons.music_note), label: const Text('MUSIC'))),
            const SizedBox(width: 10),
            Expanded(child: FilledButton.icon(
              onPressed: !running ? start : paused ? resume : pause,
              icon: Icon(!running ? Icons.play_arrow : paused ? Icons.play_arrow : Icons.pause),
              label: Text(!running ? 'START' : paused ? 'RESUME' : 'PAUSE'),
            )),
          ]),
          if (running) Padding(padding: const EdgeInsets.only(top: 8), child: FilledButton.tonal(onPressed: finish, child: const Text('FINISH RUN'))),
        ])),
      ]),
    );
  }

  Widget _value(String label, String value) => Container(
    width: 150, padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(color: Theme.of(context).cardColor, borderRadius: BorderRadius.circular(16)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: TextStyle(color: Theme.of(context).hintColor, fontSize: 12)),
      const SizedBox(height: 5), Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
    ]),
  );
}
